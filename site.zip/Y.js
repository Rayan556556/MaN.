
  // 1. تسمية الصفحة بواسطة المستخدم
let u = prompt('سمي الصفحة');
let c = document.getElementById('gg');
let v = document.createElement('h1');
function setPageTitle() {
  if (u === "") {
    alert("يرجى التسمية");
    return;
  }
  c.textContent = u;
  c.appendChild(v);
}
setPageTitle();

let tk = document.getElementById('uu');  // زر الإضافة
let us = document.getElementById('rrt'); // حقل إدخال المهمة
let dev = document.getElementById('pp'); // مكان عرض المهام

// 2. استرجاع المهام المحفوظة من localStorage أو تهيئة مصفوفة فارغة
let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

// 3. دالة لحفظ المهام في localStorage
function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// 4. دالة لإضافة مهمة جديدة إلى الصفحة مع دعم الشطب والحذف بالضغط المطول
function addTask(task) {
  let txt = document.createElement("div");
  txt.className = "task";
  txt.textContent = task.text;

  // إذا المهمة مشطوبة مسبقاً (محفوظة كمنجزة)، نطبق الشطب
  if (task.done) {
    txt.style.textDecoration = "line-through";
  }

  dev.appendChild(txt);

  // عند الضغط على المهمة: نبدل حالة الشطب ونحدث الحفظ
  txt.addEventListener("click", () => {
    task.done = !task.done;
    txt.style.textDecoration = task.done ? "line-through" : "none";
    saveTasks();
  });

  // حذف المهمة عند الضغط المطول (أكثر من 800 مللي ثانية)
  let pressTimer;
  txt.addEventListener("mousedown", () => {
    pressTimer = setTimeout(() => {
      dev.removeChild(txt);
      tasks = tasks.filter(t => t !== task);
      saveTasks();
    }, 800);
  });
  txt.addEventListener("mouseup", () => clearTimeout(pressTimer));
  txt.addEventListener("mouseleave", () => clearTimeout(pressTimer));

  // دعم لمس الموبايل للحذف بالضغط المطول (يمكن تضيفه لو حبيت)
  txt.addEventListener("touchstart", () => {
    pressTimer = setTimeout(() => {
      dev.removeChild(txt);
      tasks = tasks.filter(t => t !== task);
      saveTasks();
    }, 800);
  });
  txt.addEventListener("touchend", () => clearTimeout(pressTimer));
}

// 5. تحميل المهام المحفوظة وعرضها عند فتح الصفحة
tasks.forEach(addTask);

// 6. إضافة مهمة جديدة عند الضغط على الزر
tk.addEventListener("click", () => {
  let taskText = us.value.trim();
  if (taskText === "") {
    alert("يجب ملء الحقل");
    return;
  }
  let newTask = { text: taskText, done: false };
  tasks.push(newTask);
  saveTasks();
  addTask(newTask);
  us.value = "";
});

// باقي كود تغيير الخلفيات أو إظهار وإخفاء المحتويات (مثل الأزرار: opa، opf، ops، ...)
// تتركه كما هو عندك، لا يؤثر على الحفظ أو عرض المهام

 



  
   
   
   
   
   
   
   document.getElementById('opa').addEventListener('click' ,  function() {
  const rest = document.getElementById('restContent');
  if (rest.style.display === 'none') {
    rest.style.display = 'block';  // أظهر المحتوى
  } else {
    rest.style.display = 'none';   // أخفي المحتوى لو تكرر الضغط
  }
});
document.getElementById('opf').addEventListener('click', function() {
  document.body.style.background='#87CEEB'
  let ss = document.getElementById('g')
  
 ss.style.color='#000'
});
  
document.getElementById('ops').addEventListener('click', function() {
  document.body.style.background='#DFF0D8'
  let sss = document.getElementById('g')
 sss.style.color='#000'
});
  document.getElementById('opd').addEventListener('click', function() {
  document.body.style.background='#f1f1f1'
  let s = document.getElementById('g')
 s.style.color='#000'
});
document.getElementById('opg').addEventListener('click', function() {
  document.body.style.background='#10f'
  let ssss = document.getElementById('g')
 ssss.style.color='#000'
});
document.getElementById('oph').addEventListener('click', function() {
  document.body.style.background='#1f1'
  let ysss = document.getElementById('g')
 ysss.style.color='#000'
});
document.getElementById('opj').addEventListener('click', function() {
  document.body.style.background='#266'
  let ssiis = document.getElementById('g')
 ssiis.style.color='#000'
});
document.getElementById('opl').addEventListener('click', function() {
  document.body.style.background='#000'
 let ssiios = document.getElementById('g')
 ssiios.style.color='#fff'
});

  

    
  
  
    // أولاً، تحدد العنصر


// بعدها، تغير ستايل النص

  
  // مصفوفة المهام، كل مهمة كائن فيه نص وحالة (مشطوبة أو لا)
